@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package hu.regelo.app.ui.screens

import hu.regelo.app.util.orReport

import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hu.regelo.app.AppGraph
import hu.regelo.app.data.BookCard
import hu.regelo.app.data.ContinueItem
import hu.regelo.app.data.ReadingList
import hu.regelo.app.ui.components.BookCover
import hu.regelo.app.ui.components.BookTile
import hu.regelo.app.ui.components.EmptyState
import hu.regelo.app.ui.components.LocalSnackbar
import hu.regelo.app.ui.components.SectionTitle
import hu.regelo.app.ui.components.TextInputDialog
import hu.regelo.app.ui.components.authorLabel
import hu.regelo.app.ui.components.rememberLoader
import hu.regelo.app.ui.components.runAction
import hu.regelo.app.ui.nav.Navigator
import hu.regelo.app.ui.nav.Route
import hu.regelo.app.ui.nav.Tab
import hu.regelo.app.ui.theme.Lora
import hu.regelo.app.util.relativeTime

private data class LibraryData(
    val continueItems: List<ContinueItem>,
    val saved: List<BookCard>,
    val liked: List<BookCard>,
    val lists: List<ReadingList>,
    val challenge: hu.regelo.app.data.ReadingChallenge?,
)

@Composable
fun LibraryScreen(nav: Navigator) {
    val snackbar = LocalSnackbar.current
    val scope = rememberCoroutineScope()
    val me by AppGraph.profiles.me.collectAsState()
    val downloaded by AppGraph.books.observeDownloaded().collectAsState(initial = emptyList())
    var newList by remember { mutableStateOf(false) }
    var challengeDialog by remember { mutableStateOf(false) }

    val loader = rememberLoader(Unit) {
        val cont = runCatching { AppGraph.library.continueReading() }.orReport("LibraryScreen", emptyList())
        val savedIds = runCatching { AppGraph.library.savedBookIds() }.orReport("LibraryScreen", emptyList())
        val likedIds = runCatching { AppGraph.social.likedBookIds() }.orReport("LibraryScreen", emptyList())
        val all = runCatching { AppGraph.books.toCards(AppGraph.books.byIds((savedIds + likedIds).distinct())) }.orReport("LibraryScreen", emptyList()).associateBy { it.book.id }
        LibraryData(
            continueItems = cont,
            saved = savedIds.mapNotNull { all[it] },
            liked = likedIds.mapNotNull { all[it] },
            lists = runCatching { AppGraph.library.myLists() }.orReport("LibraryScreen", emptyList()),
            challenge = runCatching { AppGraph.reading.challenge() }.orReport("LibraryScreen", null),
        )
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("Könyvtár", style = MaterialTheme.typography.headlineSmall)
                    me?.let { Text("Szia, ${it.displayName.substringBefore(' ')}!", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            },
            actions = {
                IconButton(onClick = { nav.push(Route.Notes) }) { Icon(Icons.Default.EditNote, "Jegyzeteim és kiemeléseim") }
                IconButton(onClick = { nav.open(Tab.DISCOVER, Route.Search()) }) { Icon(Icons.Default.Search, "Keresés") }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
        )
        PullToRefreshBox(isRefreshing = loader.refreshing, onRefresh = { loader.reload() }, modifier = Modifier.fillMaxSize()) {
            val data = loader.value
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                if (data == null) {
                    item { hu.regelo.app.ui.components.LoadingBox(Modifier.height(240.dp)) }
                } else {
                    // Olvasási kihívás (éves cél)
                    data.challenge?.let { ch ->
                        item { Spacer(Modifier.height(4.dp)); hu.regelo.app.ui.components.ReadingChallengeCard(ch, onClick = { challengeDialog = true }) }
                    }
                    // Olvasás folytatása
                    if (data.continueItems.isNotEmpty()) {
                        item { SectionTitle("Olvasás folytatása") }
                        val first = data.continueItems.first()
                        item {
                            ContinueCard(first, onClick = { nav.push(Route.Reader(first.card.book.id)) }, onRemove = {
                                scope.runAction(snackbar, "Eltávolítva a folyamatban lévők közül.") { AppGraph.library.removeFromContinue(first.card.book.id); loader.reload() }
                            })
                        }
                        if (data.continueItems.size > 1) {
                            item {
                                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    items(data.continueItems.drop(1), key = { it.card.book.id }) { ci ->
                                        Box {
                                            BookTile(ci.card, onClick = { nav.push(Route.Reader(ci.card.book.id)) }, progress = ci.progress.percent / 100f)
                                            IconButton(
                                                onClick = { scope.runAction(snackbar, "Eltávolítva a folyamatban lévők közül.") { AppGraph.library.removeFromContinue(ci.card.book.id); loader.reload() } },
                                                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp)
                                                    .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.45f), androidx.compose.foundation.shape.CircleShape),
                                            ) { Icon(Icons.Default.Close, "Eltávolítás a folyamatban lévők közül", Modifier.size(16.dp), tint = androidx.compose.ui.graphics.Color.White) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (data.continueItems.isEmpty() && data.saved.isEmpty() && data.liked.isEmpty() && downloaded.isEmpty()) {
                        item {
                            EmptyState(
                                Icons.AutoMirrored.Filled.MenuBook,
                                "Üres még a polcod",
                                "Fedezz fel történeteket, és add hozzá őket a könyvtáradhoz. Itt folytathatod az olvasást bármelyik eszközön.",
                            ) { FilledTonalButton(onClick = { nav.select(Tab.DISCOVER) }) { Text("Felfedezés") } }
                        }
                    }
                    if (data.saved.isNotEmpty()) {
                        item { SectionTitle("Könyvtáram (${data.saved.size})") }
                        item { Shelf(data.saved) { nav.push(Route.BookDetail(it)) } }
                    }
                    if (downloaded.isNotEmpty()) {
                        item { SectionTitle("Letöltve – offline is olvasható") }
                        item {
                            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                items(downloaded, key = { it.id }) { b ->
                                    Column(Modifier.width(112.dp).clickable { nav.push(Route.Reader(b.id)) }) {
                                        Box {
                                            BookCover(b.title, b.penName, b.coverUrl, b.coverColorHex, width = 112.dp)
                                            Icon(Icons.Default.DownloadDone, null, Modifier.align(Alignment.BottomEnd).padding(4.dp).size(18.dp), tint = MaterialTheme.colorScheme.surface)
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text(b.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                    if (data.liked.isNotEmpty()) {
                        item { SectionTitle("Kedvencek") }
                        item { Shelf(data.liked) { nav.push(Route.BookDetail(it)) } }
                    }
                    item { SectionTitle("Olvasási listáim", action = "Új lista", onAction = { newList = true }) }
                    if (data.lists.isEmpty()) {
                        item {
                            Text(
                                "Készíts saját listákat (pl. „Nyári olvasmányok”). A nyilvános listák a profilodon is látszanak.",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp),
                            )
                        }
                    }
                    items(data.lists, key = { "list-" + it.id }) { list ->
                        Card(
                            onClick = { nav.push(Route.ReadingList(list.ownerId, list.id)) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bookmarks, null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(list.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${list.bookIds.size} könyv · ${if (list.isPublic) "nyilvános" else "privát"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val ch = loader.value?.challenge
    if (challengeDialog && ch != null) hu.regelo.app.ui.components.ReadingChallengeDialog(ch, onDismiss = { challengeDialog = false }, onChanged = { loader.reload() })
    if (newList) {
        TextInputDialog(
            title = "Új olvasási lista", label = "Lista neve", confirm = "Létrehozás",
            onConfirm = { name -> scope.runAction(snackbar, "Lista létrehozva.") { AppGraph.library.createList(name, isPublic = false); loader.reload() } },
            onDismiss = { newList = false },
        )
    }
}

@Composable
private fun ContinueCard(item: ContinueItem, onClick: () -> Unit, onRemove: () -> Unit) {
    val b = item.card.book
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BookCover(b, item.card.author?.displayName, width = 76.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(b.title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Eltávolítás a folyamatban lévők közül", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(b.authorLabel(item.card.author?.displayName), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { item.progress.percent / 100f }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(6.dp))
                Text("${item.progress.chapterIndex + 1}. fejezet · ${item.progress.percent}% · ${relativeTime(item.progress.updatedAt)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text("Folytatás →", fontFamily = Lora, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
private fun Shelf(cards: List<BookCard>, onOpen: (String) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(cards, key = { it.book.id }) { c -> BookTile(c, onClick = { onOpen(c.book.id) }) }
    }
}
