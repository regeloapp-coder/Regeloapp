# Regélő – Android alkalmazás (v1.2.1)

Magyar írói és olvasói platform (Wattpad / Inkitt jellegű), Kotlin + Jetpack Compose.

- Csomagnév: `hu.regelo.app`
- Backend: Supabase (Postgres + RLS, Auth, Storage, Realtime), projekt: `pqmfezkvaslqedalwwnn` (Frankfurt)
- Push: Firebase Cloud Messaging (`regelo` projekt) + `send-community-push` Edge Function
- Offline-first: minden írás azonnal a telefonra mentődik (Room), a felhőbe a háttérben szinkronizál (WorkManager)

## Fordítás
Android Studio › Open › ez a mappa › (Gradle sync) › Build › Build App Bundle(s) / APK(s) › Build APK(s).
Az APK: `app/build/outputs/apk/debug/app-debug.apk`

## Adatbázis
A `supabase/` mappában lévő SQL fájlok idempotensek (többször is futtathatók) a Supabase SQL Editorban.

## Mentés
Ez a mappa a teljes forráskód. Készíts róla rendszeresen másolatot (pl. OneDrive vagy GitHub privát tároló),
hogy egy véletlen törlés ne okozzon gondot.

## Kapcsolat
Hivatalos e-mail: regeloapp@gmail.com · Hivatalos profil az appban: @regelohivatalos (moderátor, hírei minden felhasználónak mennek).

## Változások
- **1.2.1** – Teljes átvizsgálás és hibajavítás:
  az időzített történeteket a szerver jelenteti meg a megadott napon (magyar idő szerint, 10 percenként ellenőrizve), akkor is, ha az app nincs megnyitva;
  a komment- és válaszértesítés az olvasót a hozzászólás bekezdésénél nyitja meg; a törölt kommentek válaszai „elrejtett” szál alatt maradnak láthatók;
  kijelentkezés előtt figyelmeztetés, ha valami még nincs feltöltve; értékelés törölhető; a fejezetek sorszáma és az „Itt tartasz” jelölés pontos;
  az olvasási kihívásban egy újraolvasás a következő évben külön számít; üzenetküldés akkor is befejeződik, ha közben elhagyod a képernyőt;
  a borítókivágás nem akasztja meg a felületet; táblagépen és fekvő módban helyesebb elrendezés; biztonságosabb keresés és fájlimportálás;
  adatbázis-gyorsítás (indexek, egyszerűbb jogosultsági szabályok), szigorított függvényjogosultságok; frissített AndroidX-könyvtárak,
  lint-hibák javítva. SQL: `supabase/2026-10-14_app_v1_2_1.sql`.
- **1.2.0** – Közösségi és olvasói bővítés:
  értesítés (push is) a követett szerzők új fejezeteiről és új történeteiről, valamint az elmentett / olvasott történetek új fejezeteiről;
  aktivitásfolyam a Közösség › Újdonságok fülön (új fejezetek, új történetek, hírek, vélemények, kihívások);
  „Neked ajánljuk” a Felfedezésben; olvasókörök (Közösség › Körök: közös olvasmány, témák, válaszok, némítás, tagkezelés, jelentés);
  írói kihívások (Közösség › Kihívások: meghirdetés moderátorként, nevezés publikált művel, titkos szavazás, eredményhirdetés);
  olvasóban fókusz („Ne zavarj”) mód, kijelző ébren tartása, bekezdés-kiemelések és saját jegyzetek (hosszú nyomás), felolvasás magyar hangon;
  Könyvtár › Jegyzeteim; olvasási kihívás (éves cél, végigolvasott könyvek); jelvények a profilon;
  18+ tartalmak csak életkor-megerősítés után (Beállítások › Tartalom). SQL: `supabase/2026-10-14_app_v1_2.sql`,
  Edge Function: `supabase/functions/send-community-push`.
- **1.1.1** – Új alkalmazásikon: dőlt Lora „R” rozsdaszínben, tintakék alapon (adaptív vektoros ikon + témás ikon Android 13+, új értesítési ikon). Áruházi ikon: `docs/brand/regelo-ikon-512.png`.
- **1.1.0** – Írói eszközök: saját mű exportja PDF-be (A5, könyvszerű tördelés, borító, tartalomjegyzék),
  EPUB e-könyvbe (borító, képek, tartalomjegyzék) és Word/DOCX-be (címsorstílusok, oldaltörés fejezetenként) –
  mentés a telefonra/Drive-ra vagy megosztás (Írás › ⋮ › Exportálás, illetve a történet szerkesztőjében).
  Új statisztika: olvasók, végigolvasók, napi megtekintések diagramja (30 nap), fejezetenkénti „hol tartanak az olvasók”
  kimutatás a lemorzsolódás jelzésével, fejezetkedvelések és kommentek. SQL: `supabase/2026-10-13_app_v1_1.sql`.
- **1.0.2** – Teljes átvizsgálás és javítások: a háttérben érkezett értesítésre koppintva a megfelelő képernyő nyílik
  (üzenet, profil, történet); a kijelentkezés/fióktörlés mindig végigfut (nem marad helyi adat); lejárt e-mailes link
  esetén érthető üzenet; jelszó-visszaállításnál a helyes link küldhető újra; fejezet megnyitása/bezárása már nem
  „frissíti” feleslegesen a könyvet; időzített megjelenéskor a fejezetek is publikussá válnak; dátumválasztó az időzítéshez;
  fejezetszerkesztőben látszik a piszkozat/publikus állapot és van „Publikálás” gomb; a fejezet végére érve 100% lesz
  az olvasási előrehaladás; a „Legjobbra értékelt” rendezés figyelembe veszi a keresést és a szűrőket, és a lapozás
  nem áll le idő előtt; az üzenetváltásban a legújabb üzenetek látszanak; az értesítések megnyitáskor olvasottá válnak;
  a profilnál a linkek ellenőrzése és borítókép-eltávolítás; a visszajelzések (snackbar) nem tartják fel a navigációt;
  egyéb apróságok (eltávolítás gomb a „folytatás” kártyán, gombok tördelése kis kijelzőn, elavult ikon cseréje).
- **1.0.1** – Felhasználókeresés (Felfedezés › Felhasználók, Közösség › keresés ikon; név vagy @felhasználónév, ékezet nélkül is),
  hivatalos fiók jelvénnyel, hír közzététele a profilról (hivatalos fióknál mindenkinek), hírek a profilon,
  kattintható linkek és e-mail-címek a bemutatkozásban, Beállítások › Kapcsolat és visszajelzés, hivatalos e-mail a jogi szövegekben.
  SQL: `supabase/2026-10-13_app_v1_0_1.sql`.
- **1.0.0** – Az app újraépítése a meglévő Supabase- és Firebase-projektre.
